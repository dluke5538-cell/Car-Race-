DUKE RACING V1

Contents:
- index.html
- style.css
- game.js

Current scope:
- Website only
- One private player access code
- One car
- One map
- One mission
- Five checkpoints
- Keyboard + mobile touch controls

TEST ACCESS CODE:
DUKE01

IMPORTANT:
The access code is a front-end prototype lock, not real security. Anyone who downloads the source can inspect game.js and see/change the code. For a truly private online game, the next version should use a server/backend authentication system.
